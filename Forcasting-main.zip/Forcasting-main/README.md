# forecasting
A repository for forecasting | ARIMA | Holt's Winter | Regression.

time series decomposition

![](https://github.com/kshitij-pro/forecasting/blob/c72d9f496be9eff30833571d13b790a0b41e767c/Screenshot%202021-08-18%20222415.png)

visualizing ARIMA model prediction--

![](https://github.com/kshitij-pro/forecasting/blob/b42556d877848b9cea47d951fcc55db430838084/Screenshot%202021-08-18%20222439.png)

ARIMA accuracy--

![](https://github.com/kshitij-pro/forecasting/blob/c613bedbe291408eafb368dc6fad2fe541f562d5/Screenshot%202021-08-18%20222924.png)

Prophet model accuracy--

![](https://github.com/kshitij-pro/forecasting/blob/0667881d074b9982bb3bba7d740d9fd02ef8e041/Screenshot%202021-08-18%20222956.png)
